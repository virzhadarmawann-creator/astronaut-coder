# ASTRONAUT CODER — Android project

Tema: Space Explorer / NASA-inspired. Aplikasi dibuat untuk Android, dengan konten lokal dan tanpa kebutuhan koneksi internet untuk fitur dasar.

## Yang sudah ada pada source prototype
- Beranda dan navigasi mobile.
- Editor teks kode lokal.
- Menjalankan JavaScript sederhana di WebView (bukan Kotlin/Java).
- Penyimpanan proyek di localStorage aplikasi.
- Panduan coding offline sederhana berbasis aturan, bukan AI generatif.
- Materi dan latihan coding dasar.
- Mode gelap/terang.
- Halaman status Build APK yang menjelaskan keterbatasan secara jujur.

## Belum tersedia
- File APK hasil kompilasi di dalam paket ini.
- Compiler Kotlin/Java/Gradle di dalam aplikasi.
- Pembuatan APK dari project pengguna langsung di HP.
- AI generatif penuh offline.
- Syntax highlighting dan auto-complete profesional.

## Build APK
Project perlu dibangun dengan Android SDK dan Gradle pada komputer atau layanan build Android. Buka folder project menggunakan Android Studio, lalu build APK. Tidak diperlukan aplikasi coding tambahan oleh pengguna akhir setelah APK berhasil dibuat dan dipasang; namun proses kompilasi project ini tetap memerlukan toolchain build.

## Catatan
Ini adalah prototype awal, bukan aplikasi IDE Android lengkap. Jangan mengiklankan tombol Build APK sebagai sudah berfungsi sampai compiler dan pipeline build sungguhan ditambahkan.
